import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';
import 'package:territory_app/hex_grid.dart';

void main() {
  test('cell centre maps back to the same cell', () {
    final key = HexGrid.keyFor(const LatLng(29.1492, 75.7217));
    final c = HexGrid.center(key)!;
    expect(HexGrid.keyFor(c), key);
  });

  test('boundary has 6 corners and nearby points share a cell', () {
    const p = LatLng(29.1492, 75.7217);
    expect(HexGrid.boundary(HexGrid.keyFor(p))!.length, 6);
    expect(HexGrid.keyFor(const LatLng(29.14921, 75.72171)), HexGrid.keyFor(p));
  });

  test('invalid key returns null', () {
    expect(HexGrid.boundary('bad'), isNull);
  });
}
