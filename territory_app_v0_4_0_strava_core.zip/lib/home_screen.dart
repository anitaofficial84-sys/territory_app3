import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'activity_model.dart';

const _green = Color(0xFF12A150);
const _ink = Color(0xFF14191F);
const _muted = Color(0xFF6B7280);
const _line = Color(0xFFE5E7EB);
const _activitiesKey = 'territory_activities_v2';
const _cellsKey = 'territory_hex_cells';
const _coinsKey = 'territory_coins';
const _xpKey = 'territory_king_xp';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.onRecord, required this.onOpenMap, required this.onOpenActivity});
  final VoidCallback onRecord;
  final VoidCallback onOpenMap;
  final void Function(Activity) onOpenActivity;
  @override State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  List<Activity> _activities = [];
  int _cells = 0, _coins = 0, _xp = 0;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() { _activities = decodeActivities(p.getString(_activitiesKey)); _cells=(p.getStringList(_cellsKey)??[]).length; _coins=p.getInt(_coinsKey)??0; _xp=p.getInt(_xpKey)??0; });
  }
  double get totalKm => _activities.fold(0, (s,a)=>s+a.distanceKm);
  int get totalMoving => _activities.fold(0, (s,a)=>s+a.movingSeconds);
  int get streak => _activities.isEmpty ? 0 : 1;
  String _pace(double v) => v <= 0 ? '--:--' : '${v.floor().toString().padLeft(2,'0')}:${((v-v.floor())*60).round().toString().padLeft(2,'0')}';
  String _dur(int s) => '${(s~/3600).toString().padLeft(2,'0')}:${((s%3600)~/60).toString().padLeft(2,'0')}:${(s%60).toString().padLeft(2,'0')}';
  @override Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFFF4F5F7),
    appBar: AppBar(title: const Text('TERRITORY', style: TextStyle(letterSpacing: 3, fontWeight: FontWeight.w900)), backgroundColor: Colors.transparent, elevation: 0),
    body: RefreshIndicator(onRefresh: _load, child: ListView(padding: const EdgeInsets.fromLTRB(16,0,16,32), children: [
      _hero(), const SizedBox(height:12), _stats(), const SizedBox(height:12), _recent(),
    ])),
  );
  Widget _hero() => Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color:_ink,borderRadius:BorderRadius.circular(22)), child: Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
    const Text('Your training', style: TextStyle(color:Colors.white70)), const SizedBox(height:5),
    Text('${totalKm.toStringAsFixed(2)} km', style: const TextStyle(color:Colors.white,fontSize:34,fontWeight:FontWeight.w900)),
    Text('${_activities.length} activities  •  ${_dur(totalMoving)} moving time', style: const TextStyle(color:Colors.white60)), const SizedBox(height:14),
    FilledButton.icon(onPressed: widget.onRecord, icon: const Icon(Icons.play_arrow), label: const Text('Record activity'), style: FilledButton.styleFrom(backgroundColor:_green, foregroundColor:Colors.white)),
  ]));
  Widget _stats()=>Card(color:Colors.white, elevation:0, child:Padding(padding:const EdgeInsets.all(16), child:Row(children:[_metric('Activities','${_activities.length}'),_metric('Territory','$_cells'),_metric('Coins','$_coins'),_metric('King XP','$_xp')]))) ;
  Widget _metric(String a,String b)=>Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(fontSize:11,color:_muted)),const SizedBox(height:3),Text(b,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800,color:_ink))]));
  Widget _recent()=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Padding(padding:EdgeInsets.only(left:4,bottom:8),child:Text('Recent activities',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800))),
    if(_activities.isEmpty) Card(elevation:0,child:const Padding(padding:EdgeInsets.all(20),child:Text('No activities yet. Your completed runs will appear here.'))),
    ..._activities.reversed.take(10).map((a)=>Card(elevation:0,margin:const EdgeInsets.only(bottom:8),child:ListTile(onTap:()=>widget.onOpenActivity(a),leading:CircleAvatar(backgroundColor:const Color(0xFFE8F5EC),child:const Icon(Icons.directions_run,color:_green)),title:Text('${a.distanceKm.toStringAsFixed(2)} km ${a.sport}',style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('${_pace(a.avgPaceMinPerKm)}/km  •  ${_dur(a.movingSeconds)}  •  ${a.elevationGainM.round()} m'),trailing:const Icon(Icons.chevron_right))))]);
}
