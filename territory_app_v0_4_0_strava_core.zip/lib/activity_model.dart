import 'dart:convert';
import 'package:latlong2/latlong.dart';

class ActivityPoint {
  final double lat;
  final double lng;
  final DateTime time;
  final double accuracy;
  final double altitude;

  const ActivityPoint({required this.lat, required this.lng, required this.time, required this.accuracy, required this.altitude});

  Map<String, dynamic> toJson() => {'lat': lat, 'lng': lng, 'time': time.toIso8601String(), 'accuracy': accuracy, 'altitude': altitude};
  factory ActivityPoint.fromJson(Map<String, dynamic> j) => ActivityPoint(
    lat: (j['lat'] as num).toDouble(), lng: (j['lng'] as num).toDouble(),
    time: DateTime.parse(j['time'] as String), accuracy: (j['accuracy'] as num?)?.toDouble() ?? 0,
    altitude: (j['altitude'] as num?)?.toDouble() ?? 0,
  );
  LatLng get latLng => LatLng(lat, lng);
}

class Activity {
  final String id;
  final String sport;
  final DateTime started;
  final DateTime ended;
  final double distanceKm;
  final int elapsedSeconds;
  final int movingSeconds;
  final double elevationGainM;
  final double maxSpeedKmh;
  final int newCells;
  final List<ActivityPoint> points;

  const Activity({required this.id, required this.sport, required this.started, required this.ended, required this.distanceKm,
    required this.elapsedSeconds, required this.movingSeconds, required this.elevationGainM, required this.maxSpeedKmh,
    required this.newCells, required this.points});

  double get avgPaceMinPerKm => distanceKm <= 0 ? 0 : (movingSeconds / 60) / distanceKm;
  double get avgSpeedKmh => movingSeconds <= 0 ? 0 : distanceKm / (movingSeconds / 3600);

  Map<String, dynamic> toJson() => {
    'id': id, 'sport': sport, 'started': started.toIso8601String(), 'ended': ended.toIso8601String(),
    'distance_km': distanceKm, 'elapsed_s': elapsedSeconds, 'moving_s': movingSeconds,
    'elevation_gain_m': elevationGainM, 'max_speed_kmh': maxSpeedKmh, 'new_cells': newCells,
    'points': points.map((p) => p.toJson()).toList(),
  };

  factory Activity.fromJson(Map<String, dynamic> j) => Activity(
    id: j['id'] as String, sport: j['sport'] as String? ?? 'Run',
    started: DateTime.parse(j['started'] as String), ended: DateTime.parse(j['ended'] as String),
    distanceKm: (j['distance_km'] as num).toDouble(), elapsedSeconds: (j['elapsed_s'] as num?)?.toInt() ?? 0,
    movingSeconds: (j['moving_s'] as num?)?.toInt() ?? 0, elevationGainM: (j['elevation_gain_m'] as num?)?.toDouble() ?? 0,
    maxSpeedKmh: (j['max_speed_kmh'] as num?)?.toDouble() ?? 0, newCells: (j['new_cells'] as num?)?.toInt() ?? 0,
    points: ((j['points'] as List?) ?? const []).map((e) => ActivityPoint.fromJson(Map<String, dynamic>.from(e as Map))).toList(),
  );
}

String encodeActivities(List<Activity> items) => jsonEncode(items.map((e) => e.toJson()).toList());
List<Activity> decodeActivities(String? raw) {
  if (raw == null || raw.isEmpty) return [];
  try { return (jsonDecode(raw) as List).map((e) => Activity.fromJson(Map<String, dynamic>.from(e as Map))).toList(); }
  catch (_) { return []; }
}
